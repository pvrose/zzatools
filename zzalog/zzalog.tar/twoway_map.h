#ifndef __TWOWAY_MAP__
#define __TWOWAY_MAP__

#include <unordered_map>

using namespace std;

namespace zzalib {
	template <class FIRST, class SECOND> class twowayay_map
	{
	public:
		twoway_map();
		~twoway_map();

		void emplace(FIRST first, SECOND second);
		unordered_map<FIRST, SECOND>::iterator find_first(FIRST key);
		unordered_map<SECOND, FIRST>::iterator find_second(SECOND key);

	protected:
		unordered_map<FIRST, SECOND> map12;
		unordered_map<SECOND, FIRST> map21;
		
	};

}

#endif
