#include "qth_dialog.h"
#include "../zzalib/callback.h"
#include "../zzalib/rig_if.h"
#include "../zzalib/utils.h"

#include "record.h"
#include "pfx_data.h"
#include "prefix.h"
#include "status.h"
#include "tabbed_forms.h"
#include "intl_widgets.h"
#include "qso_manager.h"
#include "dxa_if.h"

#include <set>

#include <FL/Fl_Preferences.H>
#include <FL/Fl_Input_Choice.H>
#include <FL/Fl_Light_Button.H>
#include <FL/Fl_Button.H>
#include <FL/Fl_Int_Input.H>
#include <FL/Fl_Float_Input.H>
#include <FL/fl_ask.H>

using namespace zzalog;
using namespace zzalib;

extern Fl_Preferences* settings_;
extern pfx_data* pfx_data_;
extern status* status_;
extern tabbed_forms* tabbed_forms_;
extern rig_if* rig_if_;
extern qso_manager* qso_manager_;
extern dxa_if* dxa_if_;

// QTH group constructor
qth_dialog::qth_dialog(string qth_name) :
	win_dialog(10, 10)
{
	qth_name_ = qth_name;

	// Get settings
	Fl_Preferences stations_settings(settings_, "Stations");
	Fl_Preferences qths_settings(stations_settings, "QTHs");
	bool exists = qths_settings.groupExists(qth_name_.c_str());
	my_settings_ = new Fl_Preferences(qths_settings, qth_name_.c_str());

	// Create window
	string label;
	if (exists) {
		label = "Add QTH: " + qth_name_;
	}
	else {
		label = "Modify QTH: " + qth_name_;
	}
	copy_label(label.c_str());

	// Read settings
	load_values();
	// Create the form
	create_form(0, 0);
	// Enable widgets
	enable_widgets();
}

// Destructor
qth_dialog::~qth_dialog() {
}

// Get initial data from settings - additional ones for the QTH group
void qth_dialog::load_values() {
	// Get the QTH details
	char* temp;
	my_settings_->get("Operator Name", temp, "");
	current_qth_.name = temp;
	free(temp);
	my_settings_->get("Street", temp, "");
	current_qth_.street = temp;
	free(temp);
	my_settings_->get("District", temp, "");
	current_qth_.area = temp;
	free(temp);
	my_settings_->get("City", temp, "");
	current_qth_.city = temp;
	free(temp);
	my_settings_->get("Postcode", temp, "");
	current_qth_.postcode = temp;
	free(temp);
	my_settings_->get("Locator", temp, "");
	current_qth_.locator = temp;
	free(temp);
	my_settings_->get("DXCC Name", temp, "");
	current_qth_.dxcc_name = temp;
	free(temp);
	my_settings_->get("DXCC Id", temp, "");
	current_qth_.dxcc_id = temp;
	free(temp);
	my_settings_->get("State", temp, "");
	current_qth_.state = temp;
	free(temp);
	my_settings_->get("County", temp, "");
	current_qth_.county = temp;
	free(temp);
	my_settings_->get("CQ Zone", temp, "");
	current_qth_.cq_zone = temp;
	free(temp);
	my_settings_->get("ITU Zone", temp, "");
	current_qth_.itu_zone = temp;
	free(temp);
	my_settings_->get("Continent", temp, "");
	current_qth_.continent = temp;
	free(temp);
	my_settings_->get("IOTA", temp, "");
	current_qth_.iota = temp;
	free(temp);
	my_settings_->get("Description", temp, "");
	current_qth_.description = temp;
	free(temp);
}

// create the form - additional widgets for QTH settings
void qth_dialog::create_form(int X, int Y) {

	// Explicitly call begin to ensure that we haven't had too many ends.
	begin();

	labelsize(FONT_SIZE);

	const int WIP = WBUTTON * 2;

	// Column 1: Opeartor name and address
	int curr_x = X + GAP;
	int curr_y = Y + HTEXT;
	int max_w = curr_x - X;
	int max_h = curr_y - Y;
	// Operator name
	ip_name_ = new Fl_Input(curr_x, curr_y, WIP, HBUTTON, "Op. Name");
	ip_name_->labelsize(FONT_SIZE);
	ip_name_->labelfont(FONT);
	ip_name_->align(FL_ALIGN_TOP | FL_ALIGN_CENTER);
	ip_name_->textfont(FONT);
	ip_name_->textsize(FONT_SIZE);
	ip_name_->when(FL_WHEN_RELEASE);
	ip_name_->value(current_qth_.name.c_str());
	ip_name_->callback(cb_value<Fl_Input, string>, (void*)&current_qth_.name);
	ip_name_->tooltip("Enter operator name");
	// Address line 1 (
	curr_y += HBUTTON + HTEXT;
	ip_address1_ = new Fl_Input(curr_x, curr_y, WIP, HBUTTON, "Street");
	ip_address1_->labelsize(FONT_SIZE);
	ip_address1_->labelfont(FONT);
	ip_address1_->align(FL_ALIGN_TOP | FL_ALIGN_CENTER);
	ip_address1_->textfont(FONT);
	ip_address1_->textsize(FONT_SIZE);
	ip_address1_->when(FL_WHEN_RELEASE);
	ip_address1_->value(current_qth_.street.c_str());
	ip_address1_->callback(cb_value<Fl_Input, string>, (void*)&current_qth_.street);
	ip_address1_->tooltip("Enter Street address - forms MY_STREET");
	// Address line 2
	curr_y += HBUTTON + HTEXT;
	ip_address2_ = new Fl_Input(curr_x, curr_y, WIP, HBUTTON, "Area");
	ip_address2_->labelsize(FONT_SIZE);
	ip_address2_->labelfont(FONT);
	ip_address2_->align(FL_ALIGN_TOP | FL_ALIGN_CENTER);
	ip_address2_->textfont(FONT);
	ip_address2_->textsize(FONT_SIZE);
	ip_address2_->when(FL_WHEN_RELEASE);
	ip_address2_->value(current_qth_.area.c_str());
	ip_address2_->callback(cb_value<Fl_Input, string>, (void*)&current_qth_.area);
	ip_address2_->tooltip("Enter area within town/city - ignored in ADIF");
	// Address line 3
	curr_y += HBUTTON + HTEXT;
	ip_address3_ = new Fl_Input(curr_x, curr_y, WIP, HBUTTON, "Town/City");
	ip_address3_->labelsize(FONT_SIZE);
	ip_address3_->labelfont(FONT);
	ip_address3_->align(FL_ALIGN_TOP | FL_ALIGN_CENTER);
	ip_address3_->textfont(FONT);
	ip_address3_->textsize(FONT_SIZE);
	ip_address3_->when(FL_WHEN_RELEASE);
	ip_address3_->value(current_qth_.city.c_str());
	ip_address3_->callback(cb_value<Fl_Input, string>, (void*)&current_qth_.city);
	ip_address3_->tooltip("Enter town/city - forms MY_CITY");
	// Address line 4
	curr_y += HBUTTON + HTEXT;
	ip_address4_ = new Fl_Input(curr_x, curr_y, WIP, HBUTTON, "Postal code");
	ip_address4_->labelsize(FONT_SIZE);
	ip_address4_->labelfont(FONT);
	ip_address4_->align(FL_ALIGN_TOP | FL_ALIGN_CENTER);
	ip_address4_->textfont(FONT);
	ip_address4_->textsize(FONT_SIZE);
	ip_address4_->when(FL_WHEN_RELEASE);
	ip_address4_->value(current_qth_.postcode.c_str());
	ip_address4_->callback(cb_ip_upper, (void*)&current_qth_.postcode);
	ip_address4_->tooltip("Enter Postcode - forms MY_POSTCODE");

	max_h += 5 * (HBUTTON + HTEXT);
	max_w += WIP + GAP;
	curr_y = Y + HTEXT;
	curr_x += WIP + GAP;

	// Locator
	ip_locator_ = new Fl_Input(curr_x, curr_y, WIP, HBUTTON, "Locator");
	ip_locator_->labelsize(FONT_SIZE);
	ip_locator_->labelfont(FONT);
	ip_locator_->align(FL_ALIGN_TOP | FL_ALIGN_CENTER);
	ip_locator_->textfont(FONT);
	ip_locator_->textsize(FONT_SIZE);
	ip_locator_->when(FL_WHEN_RELEASE);
	ip_locator_->value(current_qth_.locator.c_str());
	ip_locator_->callback(cb_ip_upper, (void*)&current_qth_.locator);
	ip_locator_->tooltip("Enter grid locator");
	// DXCC name (
	curr_y += HBUTTON + HTEXT;
	ip_dxcc_ = new Fl_Input(curr_x, curr_y, WIP, HBUTTON, "DXCC Entity");
	ip_dxcc_->labelsize(FONT_SIZE);
	ip_dxcc_->labelfont(FONT);
	ip_dxcc_->align(FL_ALIGN_TOP | FL_ALIGN_CENTER);
	ip_dxcc_->textfont(FONT);
	ip_dxcc_->textsize(FONT_SIZE);
	ip_dxcc_->when(FL_WHEN_RELEASE);
	ip_dxcc_->value(current_qth_.dxcc_name.c_str());
	ip_dxcc_->callback(cb_ip_cty, (void*)&current_qth_.dxcc_name);
	ip_dxcc_->tooltip("Enter DXCC Entity - used to generate MY_COUNTRY");
	// DXCC Reference id. number
	curr_y += HBUTTON + HTEXT;
	ip_dxcc_adif_ = new Fl_Int_Input(curr_x, curr_y, WIP, HBUTTON, "DXCC Id.");
	ip_dxcc_adif_->labelsize(FONT_SIZE);
	ip_dxcc_adif_->labelfont(FONT);
	ip_dxcc_adif_->align(FL_ALIGN_TOP | FL_ALIGN_CENTER);
	ip_dxcc_adif_->textfont(FONT);
	ip_dxcc_adif_->textsize(FONT_SIZE);
	ip_dxcc_adif_->when(FL_WHEN_RELEASE);
	ip_dxcc_adif_->value(current_qth_.dxcc_id.c_str());
	ip_dxcc_adif_->callback(cb_value<Fl_Input, string>, (void*)&current_qth_.dxcc_id);
	ip_dxcc_adif_->tooltip("Enter DXCC Id - forms MY_DXCC");
	// Primry Admin. Subdivision (E.g. US State)
	curr_y += HBUTTON + HTEXT;
	ip_admin1_ = new Fl_Input(curr_x, curr_y, WIP, HBUTTON, "1st Level");
	ip_admin1_->labelsize(FONT_SIZE);
	ip_admin1_->labelfont(FONT);
	ip_admin1_->align(FL_ALIGN_TOP | FL_ALIGN_CENTER);
	ip_admin1_->textfont(FONT);
	ip_admin1_->textsize(FONT_SIZE);
	ip_admin1_->when(FL_WHEN_RELEASE);
	ip_admin1_->value(current_qth_.state.c_str());
	ip_admin1_->callback(cb_value<Fl_Input, string>, (void*)&current_qth_.state);
	ip_admin1_->tooltip("Enter first level sub-division - eg US State - forms MY_STATE");
	// Secondary Admin. subdivision (e.g. US County)
	curr_y += HBUTTON + HTEXT;
	ip_admin2_ = new Fl_Input(curr_x, curr_y, WIP, HBUTTON, "2nd level");
	ip_admin2_->labelsize(FONT_SIZE);
	ip_admin2_->labelfont(FONT);
	ip_admin2_->align(FL_ALIGN_TOP | FL_ALIGN_CENTER);
	ip_admin2_->textfont(FONT);
	ip_admin2_->textsize(FONT_SIZE);
	ip_admin2_->when(FL_WHEN_RELEASE);
	ip_admin2_->value(current_qth_.county.c_str());
	ip_admin2_->callback(cb_value<Fl_Input, string>, (void*)&current_qth_.county);
	ip_admin2_->tooltip("Enter second level sub-division - eg US County - forms MY_COUNTY");

	max_h = max(max_h, Y + HTEXT + 5 * (HBUTTON + HTEXT));
	max_w += WIP + GAP;
	curr_y = Y + HTEXT;
	curr_x += WIP + GAP;

	// CQ Zone
	ip_cq_zone_ = new Fl_Int_Input(curr_x, curr_y, WIP, HBUTTON, "CQ Zone");
	ip_cq_zone_->labelsize(FONT_SIZE);
	ip_cq_zone_->labelfont(FONT);
	ip_cq_zone_->align(FL_ALIGN_TOP | FL_ALIGN_CENTER);
	ip_cq_zone_->textfont(FONT);
	ip_cq_zone_->textsize(FONT_SIZE);
	ip_cq_zone_->when(FL_WHEN_RELEASE);
	ip_cq_zone_->value(current_qth_.cq_zone.c_str());
	ip_cq_zone_->callback(cb_value<Fl_Input, string>, (void*)&current_qth_.cq_zone);
	ip_cq_zone_->tooltip("Enter CQ Zone - forms MY_CQ_ZONE");
	// ITU Zone
	curr_y += HBUTTON + HTEXT;
	ip_itu_zone_ = new Fl_Int_Input(curr_x, curr_y, WIP, HBUTTON, "ITU Zone");
	ip_itu_zone_->labelsize(FONT_SIZE);
	ip_itu_zone_->labelfont(FONT);
	ip_itu_zone_->align(FL_ALIGN_TOP | FL_ALIGN_CENTER);
	ip_itu_zone_->textfont(FONT);
	ip_itu_zone_->textsize(FONT_SIZE);
	ip_itu_zone_->when(FL_WHEN_RELEASE);
	ip_itu_zone_->value(current_qth_.itu_zone.c_str());
	ip_itu_zone_->callback(cb_value<Fl_Input, string>, (void*)&current_qth_.itu_zone);
	ip_itu_zone_->tooltip("Enter ITU Zone - forms MY_ITU_ZONE");
	// Continent
	curr_y += HBUTTON + HTEXT;
	ip_cont_ = new Fl_Input(curr_x, curr_y, WIP, HBUTTON, "Continent");
	ip_cont_->labelsize(FONT_SIZE);
	ip_cont_->labelfont(FONT);
	ip_cont_->align(FL_ALIGN_TOP | FL_ALIGN_CENTER);
	ip_cont_->textfont(FONT);
	ip_cont_->textsize(FONT_SIZE);
	ip_cont_->when(FL_WHEN_RELEASE);
	ip_cont_->value(current_qth_.continent.c_str());
	ip_cont_->callback(cb_ip_upper, (void*)&current_qth_.continent);
	ip_cont_->tooltip("Enter continent (2-char) - forms MY_CONT");
	// Address line 4
	curr_y += HBUTTON + HTEXT;
	ip_iota_ = new Fl_Input(curr_x, curr_y, WIP, HBUTTON, "IOTA");
	ip_iota_->labelsize(FONT_SIZE);
	ip_iota_->labelfont(FONT);
	ip_iota_->align(FL_ALIGN_TOP | FL_ALIGN_CENTER);
	ip_iota_->textfont(FONT);
	ip_iota_->textsize(FONT_SIZE);
	ip_iota_->when(FL_WHEN_RELEASE);
	ip_iota_->value(current_qth_.iota.c_str());
	ip_iota_->callback(cb_ip_upper, (void*)&current_qth_.iota);
	ip_iota_->tooltip("Enter IOTA Reference - forms MY_IOTA");

	max_h = max(max_h, Y + HTEXT + 4 * (HBUTTON + HTEXT));
	max_w += WIP + GAP;
	curr_y = Y + max_h;
	curr_x = X + GAP;

	ip_description_ = new Fl_Input(curr_x, curr_y, WIP * 2 + GAP, HBUTTON, "Description");
	ip_description_->labelsize(FONT_SIZE);
	ip_description_->labelfont(FONT);
	ip_description_->align(FL_ALIGN_TOP | FL_ALIGN_CENTER);
	ip_description_->textfont(FONT);
	ip_description_->textsize(FONT_SIZE);
	ip_description_->when(FL_WHEN_RELEASE);
	ip_description_->value(current_qth_.description.c_str());
	ip_description_->callback(cb_value<Fl_Input, string>, (void*)&current_qth_.description);
	ip_description_->tooltip("Enter Description");

	curr_y = ip_description_->y() + ip_description_->h() + GAP;
	max_h = curr_y;

	// OK Button
	Fl_Button* bn_ok = new Fl_Button(curr_x, curr_y, WBUTTON, HBUTTON, "OK");
	bn_ok->labelsize(FONT_SIZE);
	bn_ok->callback(cb_bn_ok);
	bn_ok->when(FL_WHEN_RELEASE);
	bn_ok->tooltip("Accept changes");
	// Cancel button
	curr_x += WBUTTON + GAP;
	Fl_Button* bn_cancel = new Fl_Button(curr_x, curr_y, WBUTTON, HBUTTON, "Cancel");
	bn_cancel->labelsize(FONT_SIZE);
	bn_cancel->callback(cb_bn_cancel);
	bn_cancel->when(FL_WHEN_RELEASE);
	bn_cancel->tooltip("Cancel changes");

	max_w = max(max_w, bn_cancel->x() + bn_cancel->w() + GAP);
	max_h += HBUTTON + GAP;

	// resize the group accordingly
	resizable(nullptr);
	size(max_w, max_h);
	show();
	end();
}

// Save values in settings
void qth_dialog::save_values() {
	// Clear to remove deleted entries
	my_settings_->clear();
	// Get the QTH details
	my_settings_->set("Operator Name", current_qth_.name.c_str());
	my_settings_->set("Street", current_qth_.street.c_str());
	my_settings_->set("District", current_qth_.area.c_str());
	my_settings_->set("City", current_qth_.city.c_str());
	my_settings_->set("Postcode", current_qth_.postcode.c_str());
	my_settings_->set("Locator", current_qth_.locator.c_str());
	my_settings_->set("DXCC Name", current_qth_.dxcc_name.c_str());
	my_settings_->set("DXCC Id", current_qth_.dxcc_id.c_str());
	my_settings_->set("State", current_qth_.state.c_str());
	my_settings_->set("County", current_qth_.county.c_str());
	my_settings_->set("CQ Zone", current_qth_.cq_zone.c_str());
	my_settings_->set("ITU Zone", current_qth_.itu_zone.c_str());
	my_settings_->set("Continent", current_qth_.continent.c_str());
	my_settings_->set("IOTA", current_qth_.iota.c_str());
	my_settings_->set("Description", current_qth_.description.c_str());

}

// Add values
void qth_dialog::enable_widgets() {
	ip_name_->value(current_qth_.name.c_str());
	ip_address1_->value(current_qth_.street.c_str());
	ip_address2_->value(current_qth_.area.c_str());
	ip_address3_->value(current_qth_.city.c_str());
	ip_address4_->value(current_qth_.postcode.c_str());
	ip_locator_->value(current_qth_.locator.c_str());
	ip_dxcc_->value(current_qth_.dxcc_name.c_str());
	ip_dxcc_adif_->value(current_qth_.dxcc_id.c_str());
	ip_admin1_->value(current_qth_.state.c_str());
	ip_admin2_->value(current_qth_.county.c_str());
	ip_cq_zone_->value(current_qth_.cq_zone.c_str());
	ip_itu_zone_->value(current_qth_.itu_zone.c_str());
	ip_cont_->value(current_qth_.continent.c_str());
	ip_iota_->value(current_qth_.iota.c_str());
	ip_description_->value(current_qth_.description.c_str());
}

// Callback that converts what is typed to upper-case
// v is pointer to the field in the QTH structure
void qth_dialog::cb_ip_upper(Fl_Widget* w, void* v) {
	cb_value<intl_input, string>(w, v);
	*(string*)v = to_upper(*(string*)v);
	((intl_input*)w)->value(((string*)v)->c_str());
}

// DXCC callback 
// v is pointer to the callsign field of the QTH structure
void qth_dialog::cb_ip_cty(Fl_Widget* w, void* v) {
	qth_dialog* that = ancestor_view<qth_dialog>(w);
	qth_info_t* qth = &that->current_qth_;
	cb_value<Fl_Input, string>(w, v);
	string* value = (string*)v;
	// Find prefix - either GM or GM:SCOTLAND
	size_t pos = zzalib::find(value->c_str(), value->length(), ':');
	// No colon found
	string nickname = value->substr(0, pos);
	// Get the prefix and track up to the DXCC prefix
	prefix* prefix = pfx_data_->get_prefix(nickname);
	if (prefix) {
		// Get CQZone - if > 1 supplied then message for now
		if (prefix->cq_zones_.size() > 1) {
			string message = "STATION: Multiple CQ Zones: ";
			for (unsigned int i = 0; i < prefix->cq_zones_.size(); i++) {
				string zone = to_string(prefix->cq_zones_[i]);
				message += zone;
			}
			status_->misc_status(ST_WARNING, message.c_str());
			qth->cq_zone = "";
		}
		else {
			// Set it in the QTH
			qth->cq_zone = to_string(prefix->cq_zones_[0]);
		}
		// Get ITUZone - if > 1 supplied then message for now
		if (prefix->itu_zones_.size() > 1) {
			string message = "STATION: Multiple ITU Zones: ";
			for (unsigned int i = 0; i < prefix->itu_zones_.size(); i++) {
				string zone = to_string(prefix->itu_zones_[i]);
				message += zone;
			}
			status_->misc_status(ST_WARNING, message.c_str());
			qth->itu_zone = "";
		}
		else {
			// Set it in the QTH
			qth->itu_zone = to_string(prefix->itu_zones_[0]);
		}
		// Get Continent - if > 1 supplied then message for now
		if (prefix->continents_.size() > 1) {
			string message = "STATION: Multiple Continents: ";
			for (unsigned int i = 0; i < prefix->continents_.size(); i++) {
				message += prefix->continents_[i] + "; ";
			}
			status_->misc_status(ST_WARNING, message.c_str());
			qth->continent = "";
		}
		else {
			// Set it in the QTH
			qth->continent = prefix->continents_[0];
		}
		qth->state = prefix->state_;
		// Track up to DXCC prefix record
		while (prefix->parent_ != nullptr) {
			prefix = prefix->parent_;
		}
		// Fill in DXCC fields
		qth->dxcc_id = to_string(prefix->dxcc_code_);
		qth->dxcc_name = prefix->nickname_ + ": " + prefix->name_;
	}
	else {
		// Not a valid nickname - set fields to blurgh
		qth->cq_zone = "";
		qth->itu_zone = "";
		qth->continent = "";
		qth->state = "";
		qth->dxcc_id = "";
		qth->dxcc_name = "";
	}
	// Update other widgets
	that->enable_widgets();
	that->redraw();
}

void qth_dialog::cb_bn_ok(Fl_Widget * w, void* v) {
	qth_dialog* that = ancestor_view<qth_dialog>(w);
	that->save_values();
	that->do_button(BN_OK);
}

void qth_dialog::cb_bn_cancel(Fl_Widget* w, void* v) {
	qth_dialog* that = ancestor_view<qth_dialog>(w);
	that->do_button(BN_CANCEL);
}
