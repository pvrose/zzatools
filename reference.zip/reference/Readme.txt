This archive includes a prefix list update for DX Atlas (http://www.dxatlas.com) 
Unzip all files to the Reference folder of DX Atlas. To find the Reference folder, 
type this in File Explorer:

%appdata%\Afreet\Reference


73 Alex, VE3NEA
ve3nea@dxatlas.com

